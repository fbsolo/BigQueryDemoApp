﻿using BigQueryDemoApp.Utilities;

using System;
using System.Collections.Generic;

using System.Data;
using System.Linq;

using System.IO;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Bigquery.v2;
using Google.Apis.Bigquery.v2.Data;

using Newtonsoft.Json;

namespace BigQueryDemoApp
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //  Keep the Quantiles DDL visible as long as the Query
            //  DDL (DDLQuery) pick = "QUANTILES EMP. COUNT" . . .

            this.DDLQuantiles.Visible = (this.DDLQuery.SelectedItem.Value == "4") ? true : false;

            if (!Page.IsPostBack)
            {
                for (int i = 3; i <= 100; i++)
                {
                    this.DDLQuantiles.Items.Add(new ListItem(i.ToString(), i.ToString()));
                }
                ListItem lsitem = new ListItem("2", "2");
                this.DDLQuantiles.Items.Insert(0, lsitem);
            }
        }

        private void calcStats(string paramString)
        {
            BQObject localBQObject = new BQObject();

            try
            {
                GV1.DataSource = localBQObject.returnDT(paramString);
                GV1.DataBind();
            }
            catch (Exception ex)
            {
                //  For an exception, build a message string - msgString - for a
                //  JavaScript alert. In msgString, delete  the \n and \r substrings
                //  and escape the single quotes, and build the script to write the
                //  alert itself . . .

                string msgString = "Exception: " + ex.Message.ToString() + ex.StackTrace.ToString();

                msgString = msgString.Replace("'", "\\'");
                msgString = msgString.Replace("\n", "");
                msgString = msgString.Replace("\r", "");

                string localStr = "<script language=javascript>alert('" + msgString + "')</script>";

                System.Web.HttpContext.Current.Response.Write("<script language=javascript>alert('" + msgString + "')</script>");
            }
        }

        private string endOfQueryString(string paramString)
        {
            //  If paramString ends with "WHERE", don't add
            //  anything; otherwise, add an " AND " . . .

            string localParamString = "";

            if (paramString.Substring(paramString.Length - 6) != "WHERE ")
            {
                localParamString = " AND";
            }

            return (localParamString);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //  Dynamically build the queryString value based
            //  on the user's parameter picks . . .

            string queryString = "SELECT ";

            //  Fill the DDLQuery dropdown, used to pick the BigQuery function.
            //  In the column aliases, map the "formatting" values with Unicode
            //  equivalents 
            //
            //      $ <-> x24
            //      ( <-> x28
            //      ) <-> x29
            //      = <-> x3d
            //      ^ <-> x5e
            //
            //  because character escapes won't work in BigQuery SELECT column
            //  aliasing . . .

            switch (this.DDLQuery.SelectedValue)
            {
                case "1":
                    queryString += "STDDEV(QP1) AS STDDEV_QUARTERLY_PAYROLL_x281_x3d_x24_1Kx29 ";
                    break;
                case "2":
                    queryString += "AVG(AP) AS AVG_TOTAL_ANNUAL_PAYROLL_x281_x3d_x24_1Kx29 ";
                    break;
                case "3":
                    queryString += "VARIANCE(EST) AS VARIANCE_TOTAL_ESTABLISHMENT_COUNT_x281_x3d_COUNTx5e2x29 ";
                    break;
                case "4":

                    //  For the quantiles function, DDLQuantiles will allow
                    //  a pick for the second function parameter . . .

                    if (this.DDLQuery.Visible)
                    {
                        queryString += "ROW_NUMBER() OVER (ORDER BY QUANTILE_VALUES) AS QUANTILE_NUMBER, ";
                        queryString += "QUANTILES(EMP, " + this.DDLQuantiles.SelectedValue + ") AS QUANTILE_VALUES ";
                    }
                    break;
            }

            //  BigQuery expects to see
            //
            //      {dataset name}.{table name}
            //
            //  in the FROM clause.

            queryString += "FROM BigQueryDemoAppDS.zbp11totals WHERE ";

            foreach (Control ctl in Form.Controls)
            {
                if (ctl is DropDownList)
                {
                    DropDownList localDDL = (DropDownList)ctl;

                    if ((localDDL.ID != "DDLQuery") && (localDDL.ID != "DDLQuantiles") && (localDDL.SelectedValue != "ANY"))
                    {
                        queryString += endOfQueryString(queryString);

                        if (localDDL.ID == "DDLZIP")
                        {
                            queryString += " ZIP LIKE '" + localDDL.SelectedValue + "%'";
                        }
                        else
                        {
                            queryString += " " + localDDL.ID.Substring(3, localDDL.ID.Length - 3) + " BETWEEN " + localDDL.SelectedValue;
                        }
                    }
                }
            }

            //  The queryString value ended with "WHERE " because the user
            //  picked no parameters. Delete that ending "WHERE " in this
            //  case . . .

            if (queryString.Substring(queryString.Length - 6) == "WHERE ")
            {
                queryString = queryString.Substring(0, (queryString.Length - 7));
            }

            this.calcStats(queryString);
        }

        protected void DDLQueryClause_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  If the user picked the Quantiles Employee Count
            //  query, show the quantiles dropdown / label . . .

            this.DDLQuantiles.Visible = (this.DDLQuery.SelectedItem.Value == "4") ? true : false;
            this.Label7.Visible = this.DDLQuantiles.Visible;
            this.Label8.Visible = this.DDLQuantiles.Visible;
        }
    }
}