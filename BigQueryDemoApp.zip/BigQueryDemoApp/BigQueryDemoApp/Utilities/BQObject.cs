﻿using System;
using System.Collections.Generic;

using System.Data;

using System.IO;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Bigquery.v2;
using Google.Apis.Bigquery.v2.Data;

namespace BigQueryDemoApp.Utilities
{
    public class BQObject
    {
        public BQObject()
        {
            //  Basic constructor . . .
        }

        private static Google.Apis.Bigquery.v2.BigqueryService returnService()
        {
            FileStream stream;
            UserCredential credential;

            using (stream = new FileStream(HttpContext.Current.Server.MapPath("~/client_secrets.json"), FileMode.Open, FileAccess.Read))
            {
                GoogleWebAuthorizationBroker.Folder = "Tasks.Auth.Store";
                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    new[] { BigqueryService.Scope.Bigquery },
                    "user", CancellationToken.None).Result;
            }

            //  Create and initialize the Bigquery service. Use the Project Name value
            //  from the New Project window for the ApplicationName variable.

            var Service = new BigqueryService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "BigQueryDemoApp"
            });

            return Service;
        }

        internal DataTable returnDT(string queryParam)
        {
            Google.Apis.Bigquery.v2.BigqueryService localService = returnService();
            JobsResource j = localService.Jobs;
            QueryRequest qr = new QueryRequest();
            qr.Query = queryParam;

            DataTable DT = new DataTable();
            int i;

            //  In the Developers Console, the New Project window defined an
            //  editable Project ID value. Place this value inside the quotes
            //  in the j.Query function. 

            QueryResponse response = j.Query(qr, "glass-mantra-589").Execute();

            int colCount = response.Schema.Fields.Count;

            for (i = 0; i < colCount; i++)
            {
                string localColName = "";
                DT.Columns.Add();

                //  Get the column name from the JSON response object - specifically, the
                //
                //      response.Schema.Fields[i].Name
                //
                //  property. BigQuery can't have an embedded space
                //  in a column name alias so replace embedded underscores
                //  in the alias with a " " space. Then, replace the
                //  "escaped" sequences with the intended characters . . .

                localColName = response.Schema.Fields[i].Name.Replace("_", " ");
                localColName = localColName.Replace("x24", "$");
                localColName = localColName.Replace("x28", "(");
                localColName = localColName.Replace("x29", ")");
                localColName = localColName.Replace("x3d", "=");
                localColName = localColName.Replace("x5e", "^");

                DT.Columns[i].ColumnName = localColName;
            }

            foreach (Google.Apis.Bigquery.v2.Data.TableRow row in response.Rows)
            {
                DataRow newRow = DT.NewRow();

                //  If the first data node in the first JSON response
                //  object row is null, the query returned no data for
                //  the chosen parameters - flag this in a row to place
                //  in datatable DT. Otherwise, "move" the data from
                //  the JSON response object into datatable DT rows.
                //  This case covers the first three functions in the
                //  Function for Select Clause dropdown, because
                //  BigQuery returns a single value for them. In the
                //  JSON object,
                //
                //      row.F.Count
                //
                //  counts the columns in row.

                if ((response.Rows.Count == 1) && (row.F.Count == 1) && ((string)row.F[0].V == null))
                {
                    //  If one of the single-value functions returns null,
                    //  the JSON object will have one row with a single null
                    //  value.

                    newRow[0] = "No value calculated for chosen parameters";
                    DT.Rows.Add(newRow);
                }
                else if ((response.Rows.Count == 1) && (row.F.Count == 2) && ((string)row.F[0].V == "1"))
                {
                    //  If the quantiles function returns one row with two
                    //  columns, where the first column has a "1", and the
                    //  second column has a null value
                    //
                    //      1   |   null
                    //
                    //  the BigQuery quantiles function returned zero
                    //  rows for the given parameters and data. Build
                    //  one row with appropriate messages.

                    newRow[0] = "No quantiles calculated for chosen parameters";
                    newRow[1] = "NULL";
                    DT.Rows.Add(newRow);
                }
                else
                {
                    //  In this block, a function returning a single value leads to one
                    //  row with one column in newRow. If the quantiles function can
                    //  make calculations based on the parameter values it sees, all
                    //  rows in the result set have two columns - first, the quantile
                    //  number and second, the quantile value. Loop through the JSON
                    //  to build the datatable.

                    for (i = 0; i < colCount; i++)
                    {
                        newRow[i] = (string)row.F[i].V;
                    }
                    DT.Rows.Add(newRow);
                }
            }

            return DT;
        }
    }
}